function contactMe() {
    alert("Thanks for reaching out! You can contact me at alexwebdev@email.com");
  }
  